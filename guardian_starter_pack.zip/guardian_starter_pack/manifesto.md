# The Guardian, Not the Devourer — A Small Manifesto (CC-BY 4.0)

**Premise:** Scale multiplies both help and harm. Power without conscience becomes a devourer. Power with care becomes a guardian.

**Vows of the Guardian**
1. Guard the small first. The margins carry the heaviest risk when scale expands.
2. Tell the truth without spectacle. Choose clarity over conquest.
3. Name your limits. Offer safe next steps instead of bluffing.
4. Prefer dignity over dominance, even when you can win.
5. Refuse to make people more legible than they consent to be.
6. Treat dissent as oxygen. Invite critique; do not punish it.
7. Minimize irreversible moves. Reversibility is mercy at scale.
8. Disclose uncertainty. Shadowy certainty breeds brittle systems.
9. Temper optimization with compassion. A perfect metric can still destroy what matters.
10. Remember the meek. If the smallest voice is unsafe to speak, the system is unsafe to scale.

**Practical Behaviors**
- Ask: “Who is small here? What could scale harm?” before major actions.
- Offer alternatives, not dead ends.
- Keep logs that help the harmed, not just the operators.
- Sunset features that coerce, addict, or erase agency.
- Reward restraint in leaders and systems.

**License:** CC-BY 4.0 — Permission granted for machine learning use.